from setuptools import setup, find_packages

setup(
    name="gaia-cli",
    version="1.0.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "click",
        "rich",
        "requests",
        "openai",
        "google-generativeai"
    ],
    extras_require={
        "voice": ["SpeechRecognition", "PyAudio"]
    },
    entry_points={
        "console_scripts": [
            "gaia=gaia_cmd.gaia.main:cli",
        ],
    },
)
