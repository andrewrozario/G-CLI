import logging
import subprocess
import time
import os
from typing import Dict, Any, Optional, List, Tuple
from gaia_cmd.core.communication.message import Message
from gaia_cmd.core.planning.models import ExecutionPlan, TaskStep, StepStatus
from gaia_cmd.core.ui.cli import GaiaUI
from gaia_cmd.core.execution.verifier import GaiaVerifier

class ExecutionResult:
    """Standardized output from any execution."""
    def __init__(self, stdout: str, stderr: str, exit_code: int, timeout_expired: bool = False):
        self.stdout = stdout
        self.stderr = stderr
        self.exit_code = exit_code
        self.timeout_expired = timeout_expired
        self.success = (exit_code == 0 and not timeout_expired)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "stdout": self.stdout,
            "stderr": self.stderr,
            "exit_code": self.exit_code,
            "timeout_expired": self.timeout_expired,
            "success": self.success
        }

class SafeExecutionEngine:
    """
    Executes commands securely.
    Supports local subprocess with boundaries.
    """
    def __init__(self, workspace_root: str, use_docker: bool = False):
        self.workspace_root = workspace_root
        self.use_docker = use_docker
        self.logger = logging.getLogger("ExecutionEngine")

    def execute(self, command: str, timeout: int = 60) -> ExecutionResult:
        try:
            is_unix = os.name == 'posix'
            process = subprocess.Popen(
                command,
                shell=True,
                cwd=self.workspace_root,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                preexec_fn=os.setsid if is_unix else None
            )
            stdout, stderr = process.communicate(timeout=timeout)
            return ExecutionResult(stdout=stdout, stderr=stderr, exit_code=process.returncode)
        except subprocess.TimeoutExpired:
            if is_unix:
                import signal
                os.killpg(os.getpgid(process.pid), signal.SIGKILL)
            else:
                process.kill()
            return ExecutionResult(stdout="", stderr="Timeout", exit_code=-1, timeout_expired=True)
        except Exception as e:
            return ExecutionResult(stdout="", stderr=str(e), exit_code=1)

class PlanExecutionEngine:
    """
    The Real-World Execution Engine for Gaia CLI.
    Converts plans into physical operations by routing to specialized agents.
    """
    def __init__(self, agent_manager: Any, ui: GaiaUI, workspace_root: str):
        self.agent_manager = agent_manager
        self.ui = ui
        self.workspace_root = workspace_root
        self.logger = logging.getLogger("PlanExecutionEngine")
        self.verifier = GaiaVerifier(workspace_root)

    def execute_plan(self, plan: ExecutionPlan, context: Dict[str, Any]) -> bool:
        """
        Executes a sequence of steps by detecting type and routing via AgentManager.
        """
        self.logger.info(f"Initiating manifestation of plan: {plan.goal}")
        
        while not plan.is_complete():
            runnable_steps = plan.get_next_runnable_steps()
            if not runnable_steps:
                if plan.has_failures(): return False
                break
            
            for step in runnable_steps:
                success = self.execute_step(step, context)
                if not success:
                    return False
        return True

    def execute_step(self, step: TaskStep, context: Dict[str, Any], max_retries: int = 5) -> bool:
        """
        Identifies step type, routes via AgentManager, and executes real operations.
        """
        step.status = StepStatus.RUNNING
        attempts = 0
        
        while attempts < max_retries:
            attempts += 1
            step.attempts = attempts
            self.ui.show_thinking(f"Executing {step.description} ({attempts}/{max_retries})")

            # 1. Detect Step Type & Route via AgentManager
            agent_key, action_type = self._detect_step_type(step)
            agent = self.agent_manager.get(agent_key)
            
            if not agent:
                self.logger.error(f"Routing failure: Agent '{agent_key}' not found.")
                step.status = StepStatus.FAILED
                return False

            # 2. Execute Real Operation (via Agent Interface)
            msg = Message(sender="execution_engine", receiver=agent_key, content={
                "action": "execute_step",
                "type": action_type,
                "description": step.description,
                "goal": step.goal,
                "required_files": step.required_files,
                "memory_context": context.get("memory", {})
            }, task_id=step.id)

            response = self.agent_manager.route_message(msg)
            result = response.content
            
            # 3. Handle Result & Empirical Verification
            if result.get("success"):
                v_result = self.verifier.run_empirical_check(action_type, {
                    "required_files": step.required_files,
                    "description": step.description
                })
                
                if v_result["success"]:
                    self.ui.show_manifestation("stabilized", f"Step verified: {step.id}")
                    step.status = StepStatus.COMPLETED
                    return True
                else:
                    self.ui.show_manifestation("realigning", f"Verification failed: {v_result['error']}")
            else:
                self.ui.show_manifestation("realigning", f"Operation failed: {result.get('error')}")

            # 4. Error Handling
            self._trigger_debug(step, result.get("error") or "Verification mismatch")
            time.sleep(0.5)

        step.status = StepStatus.FAILED
        return False

    def _detect_step_type(self, step: TaskStep) -> Tuple[str, str]:
        """
        Detects if the step is 'file', 'shell', or 'code' based on description.
        Returns (agent_key, action_type).
        """
        desc = step.description.lower()
        
        # FILE operations
        if any(kw in desc for kw in ["copy", "move", "rename", "delete", "branding", "replace text", "asset"]):
            return "file", "file_operation"
            
        # SHELL operations
        if any(kw in desc for kw in ["run", "install", "npm", "pip", "execute", "setup"]):
            return "shell", "system_command"
            
        # CODE operations (default)
        return "builder", "code_generation"

    def _trigger_debug(self, step: TaskStep, error: str):
        """Routes failure to DebugAgent."""
        debug_msg = Message(sender="execution_engine", receiver="debug", content={
            "action": "diagnose_and_fix",
            "error_msg": error,
            "step_description": step.description
        }, task_id=step.id)
        self.agent_manager.route_message(debug_msg)
