import json
import logging
from enum import Enum
from typing import Dict, Any, Optional
from gaia_cmd.core.llm.provider import LLMProvider
from gaia_cmd.core.llm.safe_generate import safe_generate

class TaskType(Enum):
    FILE_OPERATION = "FILE_OPERATION"
    CODE_GENERATION = "CODE_GENERATION"
    SYSTEM_COMMAND = "SYSTEM_COMMAND"
    ANALYSIS = "ANALYSIS"
    MULTI_STEP = "MULTI_STEP"

class TaskClassifier:
    """
    Intelligence layer that classifies incoming user requests into specific task types.
    Ensures the orchestrator selects the optimal execution path.
    """
    def __init__(self, llm: LLMProvider):
        self.llm = llm
        self.logger = logging.getLogger("TaskClassifier")

    def classify_task(self, prompt: str) -> Dict[str, Any]:
        """
        Analyzes the prompt using LLM to determine task type and confidence.
        """
        self.logger.info(f"Classifying task: {prompt[:50]}...")

        system_prompt = (
            "You are the Gaia CLI Task Classifier. Your job is to categorize user requests into exactly one of the following types:\n"
            "1. FILE_OPERATION: Creating, moving, deleting, or reading files without significant logic generation.\n"
            "2. CODE_GENERATION: Writing algorithms, building features, refactoring code, or implementing logic.\n"
            "3. SYSTEM_COMMAND: Running terminal commands, installing packages, or environment setup.\n"
            "4. ANALYSIS: Auditing code, searching for patterns, explaining logic, or architecture review.\n"
            "5. MULTI_STEP: Complex requests that involve multiple of the above categories or require a deep plan.\n\n"
            "Respond ONLY with a valid JSON object: {'type': 'TYPE_NAME', 'confidence': 0.XX, 'reasoning': '...'}"
        )

        try:
            response_data = safe_generate(self.llm, [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"CLASSIFY THIS TASK: {prompt}"}
            ], task_description=f"Classifying: {prompt[:30]}")
            
            content = response_data.get("content", "").strip()
            
            # Clean JSON
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0].strip()
            elif "{" in content:
                content = content[content.find("{"):content.rfind("}")+1]
            
            result = json.loads(content)
            
            # Validate type against Enum
            try:
                result["type"] = TaskType(result["type"]).value
            except ValueError:
                self.logger.warning(f"Invalid task type returned: {result['type']}. Defaulting to MULTI_STEP.")
                result["type"] = TaskType.MULTI_STEP.value
                result["confidence"] = 0.5
                
            return result

        except Exception as e:
            self.logger.error(f"Task classification failed: {e}")
            return {
                "type": TaskType.MULTI_STEP.value,
                "confidence": 0.0,
                "reasoning": f"Classification error: {str(e)}"
            }
