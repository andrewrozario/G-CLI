import json
import requests
import logging
from typing import List, Dict, Any, Optional
from gaia_cmd.core.llm.provider import LLMProvider

class LocalOllamaProvider(LLMProvider):
    """
    Real implementation of Ollama local LLM provider.
    Supports qwen2.5-coder, deepseek-coder, mistral etc.
    """
    def __init__(self, model_name: str = "qwen2.5-coder:7b", base_url: str = "http://localhost:11434"):
        super().__init__("Ollama", model_name)
        self.base_url = base_url
        self.generate_url = f"{base_url}/api/chat"

    def generate(self, prompt: Any, **kwargs) -> Dict[str, Any]:
        """
        Sends a request to local Ollama instance.
        Standardized interface: generate(prompt, **kwargs)
        """
        self.logger.info(f"Connecting to local Ollama at {self.base_url} with model {self.model_name}")
        
        # 'prompt' can be a string or a list of messages
        if isinstance(prompt, str):
            messages = [{"role": "user", "content": prompt}]
        else:
            messages = prompt

        payload = {
            "model": self.model_name,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": kwargs.get("temperature", 0.2)
            }
        }

        try:
            response = requests.post(self.generate_url, json=payload, timeout=120)
            response.raise_for_status()
            
            data = response.json()
            message = data.get("message", {})
            content = message.get("content", "")
            
            return {
                "content": content,
                "tool_calls": [],
                "model": self.model_name,
                "provider": "ollama"
            }
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Ollama connection failed: {e}")
            raise RuntimeError(f"Ollama server at {self.base_url} is unreachable or returned an error.")

    def stream(self, messages: Any):
        """
        Streams responses from Ollama.
        """
        if isinstance(messages, str):
            msgs = [{"role": "user", "content": messages}]
        else:
            msgs = messages

        payload = {
            "model": self.model_name,
            "messages": msgs,
            "stream": True
        }
        
        try:
            with requests.post(self.generate_url, json=payload, stream=True, timeout=120) as response:
                response.raise_for_status()
                for line in response.iter_lines():
                    if line:
                        chunk = json.loads(line)
                        if "message" in chunk:
                            yield chunk["message"].get("content", "")
                        if chunk.get("done"):
                            break
        except Exception as e:
            self.logger.error(f"Streaming failed: {e}")
            yield f"\n[Error: {e}]"
