# Gaia CLI - Complete Local AI CLI System Architecture

Welcome to the architectural blueprint for **Gaia CLI**. This document outlines a modular, agent-based, local-first system designed to perform end-to-end coding tasks autonomously, while maintaining the flexibility to seamlessly integrate with cloud models.

## 1. Directory Structure

The system is designed with a clear separation of concerns, ensuring that the model layer, orchestration layer, and tool execution layer are decoupled.

```text
gaia-cli/
├── gaia_cmd/
│   └── gaia/                  # Main entry point for the CLI application
├── core/
│   ├── orchestrator/          # Main agent loop (OODA/ReAct) and state management
│   ├── llm/                   # Provider interfaces (Ollama, Gemini, OpenAI)
│   ├── voice/                 # Speech-to-Text and Text-to-Speech management
│   ├── memory/                # Context window management and Long-term RAG
│   ├── tools/                 # Tool registry, interfaces, and safety sandboxing
│   └── prompt/                # Prompt templating and orchestration
├── agents/
│   ├── planner/               # Specialized sub-agent: Strategy and task breakdown
│   ├── coder/                 # Specialized sub-agent: Implementation and refactoring
│   ├── reviewer/              # Specialized sub-agent: Code review and validation
│   └── generalist/            # Specialized sub-agent: General QA and execution
├── tools/
│   ├── fs/                    # File read, write, targeted replace, AST parsing
│   ├── shell/                 # Command execution (background, interactive)
│   ├── git/                   # Version control ops (commit, branch, diff)
│   └── web/                   # Browser/Fetch for documentation lookup
├── memory/
│   ├── short_term/            # Sliding window summaries, session histories
│   └── long_term/             # Local Vector DB (Chroma/Qdrant) or SQLite (facts)
├── tui/                       # Terminal User Interface components (spinners, rich text)
├── config/                    # Global config, model routing rules, user preferences
├── scripts/                   # Build, install, and DB migration scripts
├── .env.example               # Cloud API keys (optional), Local LLM URIs
└── README.md                  # Project overview
```

---

## 2. Core Modules Explanation

### A. Provider Abstraction Layer (`core/llm/`)
This module provides a unified `Completion` interface (`generate(messages, tools)`). It abstracts the underlying API. 
* **Local-First (Ollama):** Translates standard messages to Ollama API payload, including local tool-calling emulation if the local model lacks native JSON schema support.
* **Cloud Fallback:** Routes complex requests to Gemini/OpenAI when the task complexity exceeds the local model's capability (configurable via model routing).

### B. Agent Orchestrator (`core/orchestrator/`)
The "Brain" of Gaia CLI. It does not answer queries directly. Instead, it:
1. Receives the user goal.
2. Selects the appropriate sub-agent based on the task.
3. Manages the execution lifecycle (suspending/resuming state).
4. Handles tool execution failures, injecting error logs back into the context for self-correction.

### C. Prompt Orchestration (`core/prompt/`)
Dynamic prompt builder using templating (e.g., Jinja2). It builds system prompts by combining:
* `Base System Mandates` (Safety, Security, Format)
* `Agent Specific Instructions` (e.g., Coder vs. Planner rules)
* `Injected Context` (File tree, recent terminal output, active OS)
* `Memory Injection` (User preferences, global facts)

### D. Tool System (`core/tools/` & `tools/`)
Tools are strictly typed JSON-schema definitions coupled with execution functions.
* **Sandboxing:** Shell commands are executed with bounded directories and timeout limits.
* **Granular Edits:** Uses AST-aware targeted string replacement to avoid rewriting entire files (crucial for local models with smaller context windows).

### E. Memory System (`core/memory/`)
* **Short-Term (Context Compression):** Local models suffer from rapid context degradation. This module tracks token usage. When the limit approaches, it triggers a background LLM call to summarize the early conversation history, preserving exact tool calls while compressing conversational filler.
* **Long-Term:** 
  * *Facts:* Uses local SQLite for user facts ("I prefer TypeScript").
  * *RAG:* Uses local ChromaDB to ingest repository documentation, allowing the agent to "read" massive codebases quickly via semantic search.

### F. Voice System (`core/voice/`)
Allows natural interaction via speech.
* **STT (Speech-to-Text):** Converts microphone input to text commands using pluggable providers (e.g., Google, Whisper).
* **TTS (Text-to-Speech):** Provides audible feedback on task status and success using native OS commands (e.g., macOS `say`).

---

## 3. Agent Loop Design (OODA / ReAct)

Gaia CLI uses a continuous **Observe -> Plan -> Act -> Validate** cycle instead of a single prompt-response.

1. **Observe:** The Orchestrator parses the user command and reads the current workspace state (git status, directory structure).
2. **Plan (Delegation):** If the task is complex, the `Planner Agent` breaks it down into sequential sub-tasks.
3. **Act (Execution):** The `Coder Agent` receives a sub-task. It requests tools (e.g., `read_file`, `grep_search`). The CLI executes these tools locally and feeds the result back to the Coder.
4. **Validate:** Before marking a task complete, the Coder runs validation (e.g., `npm run test`, `cargo check`). 
5. **Self-Correction:** If validation fails, the error output is fed back as an Observation, and the loop restarts until success or max iterations.

---

## 4. Execution Flow Diagram

```mermaid
sequenceDiagram
    participant User
    participant CLI_Frontend
    participant Orchestrator
    participant Memory
    participant Planner_Agent
    participant Coder_Agent
    participant Tool_Executor
    participant Local_LLM (Ollama)

    User->>CLI_Frontend: "Refactor auth module and fix tests"
    CLI_Frontend->>Orchestrator: Initialize Task
    Orchestrator->>Memory: Fetch User Preferences & Context
    Orchestrator->>Planner_Agent: "Create execution plan"
    Planner_Agent->>Local_LLM: Request Plan Outline
    Local_LLM-->>Planner_Agent: [Task 1: Read Auth, Task 2: Refactor, Task 3: Test]
    
    loop For each Task
        Orchestrator->>Coder_Agent: Execute Task
        loop Think/Act/Validate
            Coder_Agent->>Local_LLM: Prompt with Tool Schemas
            Local_LLM-->>Coder_Agent: Tool Call (e.g., grep_search)
            Coder_Agent->>Tool_Executor: Run grep_search
            Tool_Executor-->>Coder_Agent: Return matching lines
            Coder_Agent->>Local_LLM: Evaluate results & generate code
            Local_LLM-->>Coder_Agent: Tool Call (replace text)
            Coder_Agent->>Tool_Executor: Execute file modification
            Coder_Agent->>Tool_Executor: Run tests (Validation)
            Tool_Executor-->>Coder_Agent: Tests Passed
        end
        Coder_Agent-->>Orchestrator: Sub-task Complete
    end
    
    Orchestrator->>Memory: Store session summary
    Orchestrator-->>CLI_Frontend: Return final success report
    CLI_Frontend-->>User: "Refactoring complete and tests passing."
```

---

## 5. Extensibility for Future Upgrades

1. **Pluggable Architecture:** Tools and Agents implement a standard `AgentInterface` and `ToolInterface`. Upgrading Gaia to support a new language (e.g., Rust AST parsing) simply requires dropping a new tool into `tools/ast/` and registering it in `core/tools/registry.go`.
2. **Model Tiering:** Introduce a `Router` module that scores task complexity. Trivial tasks (regex matching, renaming) go to a fast, local `llama3:8b`. Complex reasoning tasks (architectural decisions) optionally prompt the user: "This task is highly complex, route to GPT-4o / Claude 3.5 Sonnet? (y/n)".
3. **Multi-Agent Swarms:** By making the Orchestrator thread-safe, multiple sub-agents can run in parallel (e.g., `Reviewer Agent` constantly checking code in the background while `Coder Agent` writes it).