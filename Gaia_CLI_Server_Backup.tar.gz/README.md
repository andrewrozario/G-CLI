# Gaia CLI - Core Agent Loop Implementation

This repository contains the core autonomous engine for **Gaia CLI**.

## Modules

### 1. `core/orchestrator/loop.py`
The main orchestrator that manages the state and executes the **Understand -> Plan -> Execute -> Validate -> Fix -> Repeat** loop.

### 2. `agents/planner/planner.py`
Decomposes high-level user goals into a verifiable DAG (Directed Acyclic Graph) of sub-tasks.

### 3. `tools/executor/executor.py`
The "hands" of Gaia. Executes shell commands, file modifications, and diagnostic reads.

### 4. `core/error_handler/handler.py`
The "critic." Analyzes failure outputs (compiler errors, test failures) to provide actionable feedback for the next loop iteration.

### 5. `core/llm/provider.py`
Abstraction layer for local (Ollama) and cloud (Gemini/OpenAI) LLMs.

### 6. `core/voice/manager.py`
Voice Interaction System. Enables Speech-to-Text command recognition and Text-to-Speech feedback.

## Running the Engine

Ensure you have Python 3.10+ installed.

```bash
cd "/Users/dr.andrewrozario/Gaia CLI"
export PYTHONPATH=$PYTHONPATH:.
python3 gaia_cmd/gaia/main.py "Your Goal"
```

### Voice Mode
To use voice commands, ensure you have `SpeechRecognition` and `PyAudio` installed, then run:
```bash
python3 gaia_cmd/gaia/main.py --voice
```
Or explicitly listen:
```bash
python3 gaia_cmd/gaia/main.py listen
```

## Production Design Features
- **Stateless Execution:** Tasks are designed to be idempotent where possible.
- **Recursive Self-Correction:** When a task fails, the `ErrorAnalyzer` feeds back into the `Orchestrator`, which triggers a retry with the suggested fix.
- **Strict Validation:** Tasks are not marked complete until the `ToolExecutor` confirms the validation criteria (e.g., exit code 0).
- **Extensible Registry:** Adding a new tool is as simple as adding a method to `ToolExecutor` and registering it in the mapping.
